﻿using Expense_Tracker_App.Models;

namespace Expense_Tracker_App.Interfaces
{
    public interface IUserRepository : IRepository<int, User>
    {
        Task<User> GetByUsernameAndPasswordAsync(string username, string password);
    }
}
