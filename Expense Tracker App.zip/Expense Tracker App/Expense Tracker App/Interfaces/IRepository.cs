﻿using Expense_Tracker_App.Models;
using System.Linq.Expressions;

namespace Expense_Tracker_App.Interfaces
{
    public interface IRepository<K, T> where T : class
    {
        Task<T> GetAsync(K key);
        Task<ICollection<T>> GetAllAsync();
        Task<T> AddAsync(T item);
        Task<T> UpdateAsync(K key, T item);
        Task<T> DeleteAsync(K key);
        Task<T> SetAsDeleteAsync(K key);

        // Generic method to find entities by a condition
        Task<T> FindAsync(Expression<Func<T, bool>> predicate);
        Task<ICollection<T>> FindAllAsync(Expression<Func<T, bool>> predicate);
    }
}
