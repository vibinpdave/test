﻿using Expense_Tracker_App.Models;

namespace Expense_Tracker_App.Interfaces
{
    public interface ICategoryRepository : IRepository<int, Category>
    {
    }
}
