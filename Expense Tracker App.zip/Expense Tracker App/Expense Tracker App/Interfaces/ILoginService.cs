﻿using Expense_Tracker_App.Models.DTOs;

namespace Expense_Tracker_App.Interfaces
{
    public interface ILoginService
    {
        Task<int?> CheckUserAuthentication(string userName, string passWord);
        public Task<LoginResponseDTO> GetTokenDetails(string userName);
        public Task<LoginResponseDTO> RegisterAsync(UserDTO loginRequestDTO);
    }
}
