﻿using Expense_Tracker_App.Models;

namespace Expense_Tracker_App.Interfaces
{
    public interface IBudgetService
    {
        Task<IEnumerable<Budget>> GetBudgetsAsync();
        Task<Budget> GetBudgetByIdAsync(int id);
        Task<Budget> CreateBudgetAsync(Budget budget);
    }
}
