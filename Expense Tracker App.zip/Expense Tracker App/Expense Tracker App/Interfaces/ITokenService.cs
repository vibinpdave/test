﻿using Expense_Tracker_App.Models;

namespace Expense_Tracker_App.Interfaces
{
    public interface ITokenService
    {
        public Task<string> GenerateToken(string userName);
    }
}
