﻿using Expense_Tracker_App.Filters;
using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Models.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace Expense_Tracker_App.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ILoginService _loginService;

        public UserController(ILoginService loginService)
        {
            _loginService = loginService;
        }

        [HttpPost]
        [Route("Login")]
        [ServiceFilter(typeof(BasicAuthenticationFilter))]
        public async Task<ActionResult<LoginResponseDTO>> Login(LoginRequestDTO loginRequestDTO)
        {
            var username = User?.Identity?.Name;
            var result = await _loginService.GetTokenDetails(username);
            
            if (result == null)
                return BadRequest(new ErrorObject
                {
                    ErrorCode = 500,
                    Message = "Unable to register at this moment"
                });
            return Ok(result);           
        }

        [HttpPost]
        [Route("Register")]
        public async Task<ActionResult<LoginResponseDTO>> Register(UserDTO objUser)
        {
            var result = await _loginService.RegisterAsync(objUser); ;
            if (result == null)
                return BadRequest(new ErrorObject
                {
                    ErrorCode = 500,
                    Message = "Unable to register at this moment"
                });
            return Ok(result);
        }

    }
}
