﻿using AutoMapper;
using Expense_Tracker_App.Models.DTOs;
using Expense_Tracker_App.Models;

namespace Expense_Tracker_App.MappingProfiles
{
    public class UserProfile : Profile
    {
        public UserProfile() {
            CreateMap<UserDTO, User>()
               .ForMember(dest => dest.Password, opt => opt.Ignore()) // Ignore for manual handling
               .ForMember(dest => dest.HashKey, opt => opt.Ignore()); // Ignore for manual handling
        }
    }
}
