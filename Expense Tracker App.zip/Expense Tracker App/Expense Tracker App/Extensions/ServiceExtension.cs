﻿#region Imported Namespaces
using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Services; 
#endregion

namespace Expense_Tracker_App.Extensions
{
    public static class ServiceExtension
    {
        public static void AddServices(this IServiceCollection services)
        {
            services.AddScoped<ILoginService, LoginService>();
            services.AddScoped<ITokenService, TokenService>();
        }
    }
}
