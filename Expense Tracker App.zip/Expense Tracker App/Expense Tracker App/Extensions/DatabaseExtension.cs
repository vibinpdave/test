﻿#region Imported Namespaces
using Expense_Tracker_App.Contexts;
using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Models;
using Expense_Tracker_App.Repositories;
using Microsoft.EntityFrameworkCore; 
#endregion

namespace Expense_Tracker_App.Extensions
{
    public static class DatabaseExtension
    {
        public static void AddDatabase(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<HRContext>(
                options => options.UseSqlServer(configuration.GetConnectionString("MyDBConnection")));
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<ICategoryRepository, CategoryRepository>();
        }
    }
}
