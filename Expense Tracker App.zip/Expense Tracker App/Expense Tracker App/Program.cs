using Expense_Tracker_App.Extensions;
using Expense_Tracker_App.Filters;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);
//Repositories
//builder.Services.AddScoped<IRepository<int, User>, UserRepository>();
// Add services to the container.
builder.Services.AddJWTAuthentication(builder.Configuration);
builder.Services.AddScoped<BasicAuthenticationFilter>();

#region Mapping Profiles
builder.Services.AddAutoMapper(); 
#endregion

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(option =>
{
    option.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 1safsfsdfdfd\"",
    });
    option.AddSecurityRequirement(new OpenApiSecurityRequirement
         {
             {
                   new OpenApiSecurityScheme
                     {
                         Reference = new OpenApiReference
                         {
                             Type = ReferenceType.SecurityScheme,
                             Id = "Bearer"
                         }
                     },
                     new string[] {}
             }
         });
});

#region CORS
builder.Services.AddCors(builder => builder.AddPolicy("AllowAll", opts =>
{
    opts.AllowAnyOrigin();
    opts.AllowAnyMethod();
    opts.AllowAnyHeader();
}));
#endregion

#region Database
builder.Services.AddDatabase(builder.Configuration);
#endregion

#region Service
builder.Services.AddServices();
#endregion

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
