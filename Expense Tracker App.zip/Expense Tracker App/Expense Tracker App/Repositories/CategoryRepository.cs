﻿using Expense_Tracker_App.Contexts;
using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Models;
using Microsoft.EntityFrameworkCore;

namespace Expense_Tracker_App.Repositories
{
    public class CategoryRepository : Repository<int, Category>, ICategoryRepository
    {
        public CategoryRepository(HRContext context) : base(context)
        {
            
        }
        public override async Task<ICollection<Category>> GetAllAsync()
        {
            var categories = _context.Categories;

            // Use CountAsync() for asynchronous execution
            if (!await categories.AnyAsync())
                throw new Exception("NO Categories Exception");

            // Use ToListAsync() to fetch the categories asynchronously
            return await categories.ToListAsync();
        }

        public override async Task<Category> GetAsync(int key)
        {
            var category = await _context.Categories.SingleOrDefaultAsync(x => x.Id == key);
            if (category == null)
                throw new Exception("No such category");
            return category;
        }

    }
}
