﻿using Expense_Tracker_App.Contexts;
using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Models.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace Expense_Tracker_App.Repositories
{
    public abstract class Repository<K, T> : IRepository<K, T> where T : class, IAuditedEntity
    {
        protected readonly HRContext _context;
        protected readonly DbSet<T> _dbSet;

        public Repository(HRContext context)
        {
            _context = context;
            _dbSet = context.Set<T>();
        }
        public async Task<T> AddAsync(T item)
        {
            if (item is IAuditedEntity auditableEntity)
            {
                auditableEntity.DateCreated = DateTime.UtcNow;
                auditableEntity.DateModified = DateTime.UtcNow;
            }
            _context.Add(item);
            await _context.SaveChangesAsync();
            return item;
        }

        public async Task<T> SetAsDeleteAsync(K key)
        {
            var item = await GetAsync(key);
            if (item != null)
            {
                item.Status = (int)Enums.Status.Active;
                item.DateModified = DateTime.UtcNow;

                _context.Update(item); // Mark the entity as updated
                await _context.SaveChangesAsync();
                return item;
            }
            throw new Exception("No such item: " + typeof(T).Name);
        }

        public async Task<T> DeleteAsync(K key)
        {
            var item = await GetAsync(key);
            if (item != null)
            {
                _context.Remove(item);
                await _context.SaveChangesAsync();
                return item;
            }
            throw new Exception("No suct item " + typeof(T));
        }
        public abstract Task<ICollection<T>> GetAllAsync();

        public abstract Task<T> GetAsync(K key);

        public async Task<T> UpdateAsync(K key, T item)
        {
            var newItem = await GetAsync(key);
            if (newItem != null)
            {
                newItem.DateModified = DateTime.UtcNow;
                _context.Update(newItem);
                await _context.SaveChangesAsync();
                return item;
            }
            throw new Exception("No suct item " + typeof(T));
        }

        public virtual async Task<T> FindAsync(Expression<Func<T, bool>> predicate)
        {
            return await _dbSet.SingleOrDefaultAsync(predicate);
        }

        public virtual async Task<ICollection<T>> FindAllAsync(Expression<Func<T, bool>> predicate)
        {
            return await _dbSet.Where(predicate).ToListAsync();
        }
    }
}
