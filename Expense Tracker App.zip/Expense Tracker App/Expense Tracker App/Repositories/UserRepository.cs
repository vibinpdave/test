﻿using Expense_Tracker_App.Contexts;
using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;

namespace Expense_Tracker_App.Repositories
{
    public class UserRepository : Repository<int, User>, IUserRepository
    {
        public UserRepository(HRContext context) : base(context)
        {

        }
        public async override Task<ICollection<User>> GetAllAsync()
        {
            var users = _context.Users;
            if (users.Count() == 0)
                throw new Exception("NO users Exception");
            return users.ToList();
        }

        public async override Task<User> GetAsync(int key)
        {
            var user = await _context.Users.SingleOrDefaultAsync(x => x.Id == key);
            if (user == null)
                throw new Exception("No such user");
            return user;
        }

        public async Task<User> GetByUsernameAndPasswordAsync(string username, string password)
        {
            return await FindAsync(user =>
                user.UserName == username &&
                user.Password.SequenceEqual(new HMACSHA256(user.HashKey).ComputeHash(Encoding.UTF8.GetBytes(password))));
        }
    }
}
