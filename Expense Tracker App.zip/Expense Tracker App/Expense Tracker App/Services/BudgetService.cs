﻿using Expense_Tracker_App.Interfaces;

namespace Expense_Tracker_App.Services
{
    public class BudgetService: IBudgetService
    {
        public BudgetService()
        {

        }
    }
}
