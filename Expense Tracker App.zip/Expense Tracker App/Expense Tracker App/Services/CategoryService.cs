﻿using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Models;

namespace Expense_Tracker_App.Services
{
    public class CategoryService :ICategoryService
    {
        private readonly ICategoryRepository _categoryRepository;
        public CategoryService(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        public async Task<IEnumerable<Category>> GetCategoriesAsync()
        {
            var result = await  _categoryRepository.GetAllAsync();
            return result;
        }

        public async Task<Category> GetCategoryByIdAsync(int id)
        {
            var result = await _categoryRepository.GetAsync(id);
            return result;
        }

        public async Task<Category> CreateCategoryAsync(Category category)
        {
            //We can use fluent validation for validating inputs
            var result = await _categoryRepository.AddAsync(category);
            return result;
        }

        public async Task<bool> DeleteCategoryById(int id)
        {
            var result = await _categoryRepository.SetAsDeleteAsync(id);
            return result != null;
        }
    }
}
