﻿using AutoMapper;
using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Models;
using Expense_Tracker_App.Models.DTOs;
using System.Security.Cryptography;
using System.Text;
namespace Expense_Tracker_App.Services
{
    public class LoginService : ILoginService
    {
        private readonly IUserRepository _userRepository;
        private readonly ITokenService _tokenService;
        private readonly IMapper _mapper;

        public LoginService(IUserRepository userRepository,ITokenService tokenService, IMapper mapper)
        {
            _userRepository = userRepository;
            _tokenService = tokenService;
            _mapper = mapper;
        }

        public async Task<int?> CheckUserAuthentication(string userName, string password)
        {
            var user = await _userRepository.GetByUsernameAndPasswordAsync(userName, password);
            return user.Id;
        }

        public async Task<LoginResponseDTO> GetTokenDetails(string userName)
        {
            LoginResponseDTO responseDTO = new LoginResponseDTO()
            {
                Username = userName,
                Token = await _tokenService.GenerateToken(userName)
            };
            return responseDTO;
        }

        public async Task<LoginResponseDTO> RegisterAsync(UserDTO objUser)
        {
            HMACSHA256 hMACSHA256 = new HMACSHA256();

            // Perform basic property mapping
            var user = _mapper.Map<User>(objUser);
            // This logic can be moved to Mapping profile
            var password = hMACSHA256.ComputeHash(Encoding.UTF8.GetBytes(objUser.Password));
            user.Password = password;
            user.HashKey = hMACSHA256.Key;

            var result = _userRepository.AddAsync(user);

            if (result != null)
            {
                LoginResponseDTO responseDTO = new LoginResponseDTO()
                {
                    Username = objUser.UserName,
                    Token = await _tokenService.GenerateToken(objUser.UserName)
                };
                return responseDTO;
            }
            throw new Exception("Unable to register user at this moment");
        }

    }
}
