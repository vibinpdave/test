﻿using Expense_Tracker_App.Models.Common;

namespace Expense_Tracker_App.Models
{
    public class Budget : AuditedEntity
    {
        public int UserId { get; set; }
        public int CategoryId { get; set; }
        public decimal MonthlyBudgetAmount { get; set; }
        public decimal CurrentSpendingAmount { get; set; }
        public decimal NotificationLimit { get; set; }
        public bool IsExceeded { get; set; }

        // Navigation property to User
        public User User { get; set; }
        public Category Category { get; set; }
    }
}
