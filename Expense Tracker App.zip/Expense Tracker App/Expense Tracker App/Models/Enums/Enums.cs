﻿using System.ComponentModel;

namespace Expense_Tracker_App.Models.Enums
{
    public static class Enums
    {
        public enum TransactionType
        {
            [Description("Expense")]
            Expense=0,
            [Description("Income")]
            Income=1
        }
        public enum Status
        {
            [Description("Active")]
            Active = 0,
            [Description("Deleted")]
            Deleted = 1
        }
    }
}
