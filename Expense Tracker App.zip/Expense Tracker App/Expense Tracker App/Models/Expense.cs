﻿using Expense_Tracker_App.Models.Common;
using static Expense_Tracker_App.Models.Enums.Enums;

namespace Expense_Tracker_App.Models
{
    public class Expense : AuditedEntity
    {
        public decimal Amount { get; set; }
        public DateTime TransactionDate { get; set; }
        public string Description { get; set; }
        public TransactionType Type { get; set; } // Expense or Income

        // Foreign Keys
        public int UserId { get; set; }
        public int CategoryId { get; set; }

        // Navigation Properties
        public User User { get; set; }
        public Category Category { get; set; }
    }    
}
