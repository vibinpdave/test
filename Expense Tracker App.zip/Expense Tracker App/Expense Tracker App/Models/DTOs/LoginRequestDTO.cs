﻿namespace Expense_Tracker_App.Models.DTOs
{
    public class LoginRequestDTO
    {
        public string Username { get; set; } 
        public string Password { get; set; } 
    }
}
