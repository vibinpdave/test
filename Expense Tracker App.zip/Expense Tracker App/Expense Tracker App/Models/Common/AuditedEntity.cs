﻿using Expense_Tracker_App.Interfaces;

namespace Expense_Tracker_App.Models.Common
{
    public abstract class AuditedEntity : IAuditedEntity
    {
        public long Id { get; set; }
        public Guid Guid { get; set; }
        public long? CreatedBy { get; set; }
        public DateTime? DateCreated { get; set; }
        public long? ModifiedBy { get; set; }
        public DateTime? DateModified { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? DeletedOn { get; set; }
        public long? DeletedBy { get; set; }
        public int? Status { get; set; }
    }
}
