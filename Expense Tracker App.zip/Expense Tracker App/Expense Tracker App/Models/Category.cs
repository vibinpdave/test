﻿using Expense_Tracker_App.Models.Common;

namespace Expense_Tracker_App.Models
{
    public class Category : AuditedEntity
    {
        public string Name { get; set; }
        public bool IsCustom { get; set; } // Flag to identify custom categories

        // Navigation property
        public ICollection<Expense> Expenses { get; set; } // One-to-many relationship with Expense
        public ICollection<Budget> Budgets { get; set; } // One-to-many relationship with Budget
    }

}
