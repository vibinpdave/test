﻿using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Expense_Tracker_App.Controllers
{
    internal class ErrorObject : ModelStateDictionary
    {
        public int ErrorCode { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}