﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Expense_Tracker_App.Interfaces;
using Expense_Tracker_App.Models.Common;

namespace Expense_Tracker_App.Models
{
    public enum Roles
    {
        Admin, PowerUser, User
    }
    public class User : AuditedEntity
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string UserName { get; set; }
        public string Phone { get; set; }
        public byte[] Password { get; set; }
        public byte[] HashKey { get; set; }

        // Navigation property for related expenses
        public ICollection<Expense> Expenses { get; set; } // One-to-many relationship
        public ICollection<Budget> Budgets { get; set; } // One-to-many relationship

    }
}
